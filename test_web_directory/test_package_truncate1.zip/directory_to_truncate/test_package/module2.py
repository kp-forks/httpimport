

def dummy_func() : return 'Function Loaded'


class dummy_class :
	
	def dummy_method(self) : return 'Class and method loaded'


dummy_str = 'Constant Loaded'