def module_name():
    return 'Module B'
